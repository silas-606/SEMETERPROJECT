//manage medical records, billing, and 
//appointments. Among the information stored in the system are vital signs, 
//medical history, medication details, laboratory results, and billing information. A 
//hospital management system that keeps records of doctors, their appointments, 
//patients, staff, and more using object-oriented programming and file handling

#include<iostream>
using namespace std;
	 
class Patient{
	public:
		// PATIENT INFORMATION
	 void patientlab(){
	 	//LABRESULT FOR PATIENT
	cout<<"\t\t_________________________________\n";
	cout<<"\t\t_________________________________\n\n";
	cout<<"\t\t\tLABORATORY TEST RESULT\n";
	cout<<"\t\t__________________________________\n";
	cout<<"\t\t__________________________________\n\n";
	
	cout<<"\tPatient Information\n";
	cout<<"\t*******************\n";
	cout<<"\tName: John Doe\n";
	cout<<"\tAge: 40\n";
	cout<<"\tGender: Male\n";
	cout<<"\tGender: Male";
	 
}
   void patientbill(){
   	//PATIENT BILLS
   	cout<<"\t\t_________________________________\n";
	cout<<"\t\t_________________________________\n\n";
	cout<<"\t\t\t PATIENT BILLS\n";
	cout<<"\t\t__________________________________\n";
	cout<<"\t\t__________________________________\n\n";

   	cout<<" INVIOCE NUMBER"<<"\t\tDATA"<<"\t INVOICE DUE DATE"<<"\tTOTAL AMOUNT\n";
   	// innu               data
   	cout<<" 12345"<<"\t\t   1/02/2023"<<"\t 1/06/2023"<<"\t\t $1,903\n";
   	
   }
   
   void patientmehis(){
   	//PATIENT MEDICALHISTORY
   	cout<<"\t\t_________________________________\n";
	cout<<"\t\t_________________________________\n\n";
	cout<<"\t\t\t PATIENT MEDICAL HISTORY\n";
	cout<<"\t\t__________________________________\n";
	cout<<"\t\t__________________________________\n\n";
   	cout<<" John Doe has Allergies: Penicillin (skin rash, itching)";
	cout<<" Chronic Conditions: Type 2 diabetes (10 years, managed with medication and diet)";
	cout<<" Surgeries: Appendectomy (2015)";
	cout<<" Family Medical History: Father with heart disease, mother with hypertension";
   }
		
	};
	
// CLASS FOR DOCTOR INFORMATION
class Doctor{
	
	public:
		void doctorinfo(){
	cout<<"\t\t_________________________________\n";
	cout<<"\t\t_________________________________\n\n";
	cout<<"\t\t\t DOCTOR RECORDS\n";
	cout<<"\t\t__________________________________\n";
	cout<<"\t\t__________________________________\n\n";
		 cout<<" Doctor Name: Dr. Sarah Johnson\n";
		cout<<" Specialization: Cardiologist\n";
		cout<<" License Number: MD123456\n";
		cout<<" Hospital Affiliation: ABC Hospital\n";
		cout<<" Years of Experience: 15 years";
		
		}
};

int main(){
	cout<<"\tTHIS PROGRAM IS DESGIN TO MANAGEMENT HOSPITAL SYSTEM\n";
	 system("pause");
	 int chioce;
	cout<<"\t********WELCOME TO ABC HOSPITAL********\n";
	 begain:
	 cout<<" 1.Patient information\n";
	 cout<<" 2.Doctor Records\n";
	 cout<<" Select your chioce: ";
	 cin>>chioce;
	     switch(chioce){
	     	case 1:
	     		int option;
	     		cout<<"\n\n********WELCOME TO PATIENT INFORMATION*********\n";
	     		 restart:
	     		cout<<"\n 1.Patient labresult\n";
				cout<<" 2.Patient  bill\n";
				cout<<" 3.atient medicalhistory\n";
				cout<<" Select your option: ";
				cin>>option;
				    if(option==1){
				      Patient patientinfor;
				      patientinfor.patientlab();
					}
					else if(option==2){
						Patient patientinfor;
						patientinfor.patientbill();
					}
					else if(option==3){
						Patient patientinfor;
						patientinfor.patientmehis();
					}
					else {
						cout<<" Invalid Option";
						 goto restart;
						}
					break;	
						
		    case 2:
		    cout<<"\n\n********WELCOME TO DOCTOR RECORDS*********\n";
			 Doctor doctorinfo;
			 doctorinfo.doctorinfo();
			 break; 
			 
		 default:
		   cout<<"Invalid option.Try again";
		   goto begain;    		
		 }
	
}

